
file = open("Titanic-Dataset.csv", "r")
lines = file.readlines()
for i in range(5):
    print(lines[i])
file.close()